"""Compatibility entrypoint.

This script delegates to surgical_scraper so legacy commands still produce
the current output schema and image handling.
"""

import sys

from surgical_scraper import main


if __name__ == "__main__":
    if "--output" not in sys.argv:
        sys.argv.extend(["--output", "wordpress_ready.csv"])
    main()
