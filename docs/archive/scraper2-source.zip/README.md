# Shree Jee WooCommerce Scraper

Standalone Python scraper for BUSY ERP export files and brand product pages.

## System Architecture

The pipeline removes manual data entry by moving product data through four automated layers:

```text
[Target Marketplaces] (Amazon, Brand Portals, Directory Listings)
					│
					▼
 ┌─────────────────────────────────────────────────────────────┐
 │       PLAYWRIGHT PERSISTENT WEB RUNTIME ENGINE              │
 │  • Stealth Session Layer  • Smooth Scroll Hydration Engine  │
 │  • Network Idle Triggers  • Expandable Element Locators     │
 └────────────────────────┘────────────────────────────────────┘
													│ (HTML Source Code Matrix)
													▼
 ┌─────────────────────────────────────────────────────────────┐
 │         HYBRID SYSTEM EXTRACTION & PARSING CORE             │
 │  A. Structural extractor for native tables                  │
 │  B. Dense context Groq AI orchestrator for fallback pages   │
 └────────────────────────┘────────────────────────────────────┘
													│ (Clean HTML Table Output)
													▼
 ┌─────────────────────────────────────────────────────────────┐
 │            STANDARDIZED DATA EXPORT MATRIX                  │
 │  • SKU cleaners • WebP media sync • wordpress_ready.csv    │
 └────────────────────────┘────────────────────────────────────┘
													│ (WooCommerce Native Product Import)
													▼
 ┌─────────────────────────────────────────────────────────────┐
 │          SHREE JEE ELECTRONICS LIVE PRODUCTION REPO         │
 │  • Style2 grid harmonizer styling                           │
 │  • Anti-clipping uniformity patch                           │
 └─────────────────────────────────────────────────────────────┘
```

## Technical Milestones

- Resilient web scraping with Playwright stealth sessions and persistent browser context reuse.
- Intelligent hybrid extraction using BeautifulSoup table parsing first, then Groq-backed fallback generation for unstructured pages.
- Automated inventory normalization for SKU cleanup, brand mapping, price cleaning, and product configuration extraction.
- Deterministic media handling with WebP conversion and SKU-based image naming.
- Responsive storefront styling support for consistent archive layouts and safer category/title rendering.

## Features

- Persistent context tracking through the shared `shreejee_browser_session` profile.
- Smooth scrolling, network-idle waits, and dynamic element handling for JavaScript-heavy sites.
- Table-first parsing for `<table>`, `<th>`, and `<td>` layouts.
- AI fallback generation for pages that only expose dense plain text.
- CSV standardization for WordPress/WooCommerce imports.
- Image download, conversion, and SKU-linked output paths.
- Production sanitization pass to clean the final exported sheet.

## Key Functions

- `production_ready_automation_engine.py`
	- `execute_shree_jee_scraper_pipeline()` orchestrates the end-to-end import pipeline.
	- `extract_brand_specific_content()` and `extract_generic_content()` control structured fallback extraction.
	- `build_product_description_table()`, `build_product_short_description_table()`, and `build_product_configuration_bullets()` generate WooCommerce-ready HTML.
	- `download_and_standardize_image()` handles media conversion and naming.

- `surgical_scraper.py`
	- `fetch_any_domain_html()` retrieves rendered source from marketplace pages.
	- `extract_specs_from_tables()` and `extract_specs_from_text_block()` parse technical attributes.
	- `build_contextual_woo_tables()` creates category-aware configuration, short description, and long description output.
	- `resolve_display_brand()` normalizes brand naming before export.
	- `main()` runs the final scraping and CSV export workflow.

## Run

```powershell
.venv\Scripts\python.exe production_ready_automation_engine.py --input cleaned_model.csv --output woo_final_product_upload.csv
```

## Output Columns

- `BUSY Item Detail`
- `WooCommerce SKU`
- `cross reference tag`
- `Product Name`
- `regular price`
- `sale price`
- `product short description`
- `product description`
- `product configuration`
- `Images`
- `Gallery Images`

## Parser Strategy

- Samsung, Haier, and Voltas use brand-specific selector routing first.
- If none of those match, the generic BeautifulSoup table and list parser stays active as a safety net.
- The output keeps `BUSY Item Detail` and `WooCommerce SKU` together for ERP and BI reconciliation.

## Results And Operational Value

- Zero-manual data overhead for the 40-product batch processed by the pipeline.
- Lower memory pressure through cleanup loops and high-density context control.
- Production-ready output that can be imported directly into WooCommerce.

## Optional Proxy Support

Set either CLI flags or environment variables:

```powershell
$env:SHREEJEE_PROXY_SERVICE = "scraperapi"
$env:SHREEJEE_PROXY_KEY = "your_key_here"
```

Or use:

```powershell
.venv\Scripts\python.exe production_ready_automation_engine.py --proxy-service scraperapi --proxy-key your_key_here --render-js
```
