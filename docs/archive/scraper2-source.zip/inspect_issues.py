import pandas as pd

CSV = 'wordpress_ready.csv'
SKUS = ['WM-WA80F10B3NTL','MW-HIL3001CBSH','WD-CELFROSTFSR']

try:
    df = pd.read_csv(CSV, dtype=str).fillna('')
except Exception as e:
    print('Failed reading CSV:', e)
    raise

for sku in SKUS:
    rows = df[df['sku']==sku]
    if rows.empty:
        print('\nSKU not found:', sku)
        continue
    for i, row in rows.iterrows():
        print('\nRow index:', i)
        print('sku:', row.get('sku',''))
        print('title:', row.get('title','')[:200])
        print('Images:', row.get('Images',''))
        sd = row.get('short description','')
        desc = row.get('description','')
        print('short description present:', bool(sd and sd.strip()!=''))
        print('short description snippet:', (sd or '')[:400])
        print('description present:', bool(desc and desc.strip()!=''))
        print('description snippet:', (desc or '')[:400])
        print('---')
