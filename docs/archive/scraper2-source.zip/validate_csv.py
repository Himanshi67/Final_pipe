import pandas as pd

CSV = "wordpress_ready.csv"
PLACEHOLDER = '<p>Premium product available at Shree Jee Electronics. Detailed specifications currently updating.</p>'

try:
    df = pd.read_csv(CSV, dtype=str).fillna("")
except FileNotFoundError:
    print(f"File not found: {CSV}")
    raise

rows = len(df)
print(f"Rows: {rows}")
print("Columns:", list(df.columns))

# helper to find column
def col(*cands):
    for c in cands:
        if c in df.columns:
            return c
    return None

sku_col = col('sku','SKU','Sku')
title_col = col('title','name','Title')
images_col = col('Images','images','image')
desc_col = col('description','Description')
short_desc_col = col('short description','short description','short_description')
categories_col = col('categories','Categories','category')
brand_col = col('Brands','brands','Brand')
reg_col = col('regular price','regular_price','regular price')
sale_col = col('sale price','sale_price','sale price')

issues = []
for idx, row in df.iterrows():
    reasons = []
    sku = row.get(sku_col, '').strip() if sku_col else ''
    title = row.get(title_col, '').strip() if title_col else ''

    if not sku:
        reasons.append('missing_sku')
    if not title:
        reasons.append('missing_title')

    images = row.get(images_col, '').strip() if images_col else ''
    if not images:
        # heuristic: check if marketplace mentioned in other fields
        txt = ' '.join([str(row.get(c, '')) for c in (title_col, desc_col, short_desc_col, categories_col) if c])
        if 'amazon.' in txt.lower() or 'flipkart.' in txt.lower():
            reasons.append('images=0 (likely JS-heavy marketplace / lazy-load)')
        else:
            reasons.append('images=0 (no input image URLs or download failed)')
    else:
        count = images.count(',') + 1 if images else 0
        if count == 0:
            reasons.append('images=0 (no valid paths)')

    desc = row.get(desc_col, '').strip() if desc_col else ''
    if not desc or desc == PLACEHOLDER:
        reasons.append('missing_description')

    cats = row.get(categories_col, '').strip() if categories_col else ''
    if not cats:
        reasons.append('missing_category')

    reg = str(row.get(reg_col, '')).strip() if reg_col else ''
    sale = str(row.get(sale_col, '')).strip() if sale_col else ''
    if not reg and not sale:
        reasons.append('missing_price')

    if reasons:
        issues.append({'idx': idx, 'sku': sku, 'title': title, 'reasons': reasons, 'images': images})

# summary
from collections import Counter
all_reasons = Counter()
for it in issues:
    for r in it['reasons']:
        all_reasons[r]+=1

print('\nIssue summary:')
for reason, cnt in all_reasons.most_common():
    print(f" - {reason}: {cnt}")

print(f"\nRows with issues: {len(issues)} / {rows}")
print('\nSample problematic rows (up to 30):')
for it in issues[:30]:
    print(f"{it['idx']+1}: sku={it['sku']}, title={it['title']}, reasons={it['reasons']}, images_count={'0' if not it['images'] else str(it['images'].count(',')+1)}")

# Save a CSV with flagged issues
if issues:
    out = pd.DataFrame(issues)
    out.to_csv('validation_issues.csv', index=False)
    print('\nSaved detailed issues to validation_issues.csv')
else:
    print('\nNo issues found.')
