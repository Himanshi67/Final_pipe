import streamlit as st
import pandas as pd
import re
import io
import os
from datetime import datetime
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from PIL import Image


REQUIRED_INPUT_COLUMNS = ['sku', 'title', 'categories', 'Brands', 'regular price', 'sale price', 'url_link', 'image_url']
EXPORTED_OUTPUT_COLUMNS = ['sku', 'cross reference tag', 'configuration', 'short description', 'description', 'title', 'categories', 'regular price', 'sale price', 'Brands', '_consolidated_sku', 'Images']
IMAGE_ROOT = 'product_images_for_upload'


def build_media_base():
    return f"https://shreejeeelectronics.in/wp-content/uploads/{datetime.now():%Y/%m}"


MEDIA_BASE = build_media_base()
IRON_WORD_RE = re.compile(r'\biron\b', re.IGNORECASE)


def compact(value):
    if value is None or pd.isna(value):
        return ''
    return re.sub(r'\s+', ' ', str(value)).strip()


def number_or_blank(value):
    text = compact(value)
    if not text:
        return ''
    cleaned = text.replace(',', '').replace('₹', '').replace('$', '')
    match = re.search(r'-?\d+(?:\.\d+)?', cleaned)
    if not match:
        return ''
    try:
        return float(match.group(0))
    except Exception:
        return ''


def infer_brand(title):
    text = compact(title).upper()
    for brand in ['SAMSUNG', 'GODREJ', 'HAIER', 'USHA', 'KENSTAR', 'SUNFLAME', 'CELFROST']:
        if brand in text:
            return brand.title()
    return 'Authorized Brand'


def infer_category(title, sku, categories):
    t = compact(title).lower()
    s = compact(sku).lower()
    c = compact(categories).lower()
    full = f'{t} {s} {c}'
    if 'wash' in full or 'wm-' in full:
        return 'Washing Machines'
    if 'heater' in full or 'geyser' in full or 'wh-' in full:
        return 'Water Heaters'
    if 'microwave' in full or 'oven' in full:
        return 'Microwave Ovens'
    if 'dispenser' in full:
        return 'Water Dispensers'
    if 'cooktop' in full or 'induction' in full:
        return 'Induction Cooktops'
    if IRON_WORD_RE.search(full):
        return 'Electric Irons'
    if 'kettle' in full:
        return 'Electric Kettles'
    if 'sewing' in full or 'stitch' in full:
        return 'Sewing Machines'
    return 'Home Appliances'


def resolve_product_category(raw_item_name, raw_categories='', detected_brand=''):
    text_to_scan = ' '.join([
        compact(raw_item_name).lower(),
        compact(raw_categories).lower().replace(',', ' '),
        compact(detected_brand).lower(),
    ])

    # Washing Machines tree
    if 'top load' in text_to_scan or re.search(r'\btl\b', text_to_scan):
        return 'Washing Machines > Top load'
    if 'front load' in text_to_scan or re.search(r'\bfl\b', text_to_scan):
        return 'Washing Machines > Front Load'
    if 'semi auto' in text_to_scan or 'semi automatic' in text_to_scan or re.search(r'\bsemi\b', text_to_scan):
        return 'Washing Machines > Semi Auto'
    if 'washing machine' in text_to_scan or 'wash' in text_to_scan or 'wm-' in text_to_scan:
        return 'Washing Machines > Top load'

    # Air Conditioner tree
    if 'inverter ac' in text_to_scan or 'air conditioner inverter' in text_to_scan or 'inverter air conditioner' in text_to_scan:
        return 'Air Conditioner > Inverter AC'
    if 'split ac' in text_to_scan or re.search(r'\bsplit\b', text_to_scan) or 'sp ac' in text_to_scan:
        return 'Air Conditioner > Split AC'
    if 'window ac' in text_to_scan or re.search(r'\bwindow\b', text_to_scan) or 'win ac' in text_to_scan:
        return 'Air Conditioner > Window AC'
    if re.search(r'\bac\b', text_to_scan) or 'air conditioner' in text_to_scan or 'conditioner' in text_to_scan:
        return 'Air Conditioner > Non-Inverter AC'

    # Cooling and Freezing tree
    if 'deep freezer' in text_to_scan or re.search(r'\bdf\b', text_to_scan):
        return 'Cooling & Freezing > Deep Freezers'
    if 'air cooler' in text_to_scan or 'cooler' in text_to_scan:
        return 'Cooling & Freezing > Air Coolers'

    # LED tree
    if 'qled' in text_to_scan:
        return 'LED > QLED'
    if 'oled' in text_to_scan:
        return 'LED > OLED'
    if 'mini led' in text_to_scan or 'led' in text_to_scan or 'tv' in text_to_scan:
        return 'LED > Mini LED'

    # Home Appliances tree
    if 'refrigerator' in text_to_scan or 'fridge' in text_to_scan:
        return 'Home Appliances > Refrigerators'
    if 'fan' in text_to_scan:
        return 'Home Appliances > Fans'

    return 'Home Appliances'


def prefixed_sku(raw_sku, category):
    sku = compact(raw_sku)
    if sku.startswith(('WM-', 'WH-', 'AP-')):
        return sku
    if category == 'Washing Machines':
        return f'WM-{sku}' if sku else 'WM-UNKNOWN'
    if category == 'Water Heaters':
        return f'WH-{sku}' if sku else 'WH-UNKNOWN'
    return f'AP-{sku}' if sku else 'AP-UNKNOWN'


def wattage(text):
    match = re.search(r'(\d+\s*(?:W|Watt|Watts))', compact(text), re.IGNORECASE)
    return match.group(1) if match else 'Standard Power Rating'


def capacity_label(category, title):
    if category == 'Washing Machines':
        return 'Washing Capacity'
    if category == 'Air Conditioner':
        return 'Cooling Capacity'
    if category == 'Water Heaters':
        return 'Tank Volume'
    if category == 'Microwave Ovens':
        return 'Cavity Volume'
    if category == 'Induction Cooktops':
        return 'Cooking Zones'
    if category == 'Sewing Machines':
        return 'Stitch Configuration'
    if category == 'Electric Kettles':
        return 'Liquid Volume'
    if category == 'Electric Irons' or IRON_WORD_RE.search(compact(title)):
        return 'Soleplate Variant'
    return 'Storage Capacity'


def capacity_value(title, category):
    text = compact(title)
    if category == 'Washing Machines':
        m = re.search(r'(\d+(?:\.\d+)?\s*(?:kg|kgs?|ltr|L|litre|litres))', text, re.IGNORECASE)
        return m.group(1) if m else 'Standard Washing Capacity'
    if category == 'Air Conditioner':
        m_ton = re.search(r'(\d+(?:\.\d+)?\s*(?:ton|tr))', text, re.IGNORECASE)
        if m_ton:
            return m_ton.group(1)
        m_btu = re.search(r'(\d{4,5}\s*(?:btu))', text, re.IGNORECASE)
        return m_btu.group(1) if m_btu else 'Standard Cooling Capacity'
    if category == 'Water Heaters':
        m = re.search(r'(\d+(?:\.\d+)?\s*(?:L|liter|liters|litre|litres))', text, re.IGNORECASE)
        return m.group(1) if m else 'Standard Tank Volume'
    if category == 'Microwave Ovens':
        m = re.search(r'(\d+(?:\.\d+)?\s*(?:L|liter|liters|litre|litres))', text, re.IGNORECASE)
        return m.group(1) if m else 'Standard Cavity Volume'
    if category == 'Induction Cooktops':
        m = re.search(r'(\d+\s*(?:Zone|Zones|Burner|Burners))', text, re.IGNORECASE)
        return m.group(1) if m else '1 Cooking Zone'
    if category == 'Electric Irons' or IRON_WORD_RE.search(text):
        return 'Premium Non-Stick Glide'
    if category == 'Electric Kettles':
        m = re.search(r'(\d+(?:\.\d+)?\s*(?:ml|l|L))', text, re.IGNORECASE)
        return m.group(1) if m else 'Standard Liquid Volume'
    if category == 'Sewing Machines':
        return 'Built-in Straight Stitching'
    return 'Standard Capacity'


def configuration_text(title, category):
    t = compact(title).lower()
    if category == 'Washing Machines':
        return 'Semi-Automatic Top Load' if 'semi' in t else 'Fully Automatic Top Load'
    if category == 'Air Conditioner':
        if 'inverter' in t:
            return 'Inverter AC'
        if 'split' in t:
            return 'Split AC'
        if 'window' in t:
            return 'Window AC'
        return 'Non-Inverter AC'
    if category == 'Water Heaters':
        return 'Storage Water Geyser' if 'storage' in t else 'Instant Water Heater'
    if category == 'Microwave Ovens':
        return 'Convection Microwave Oven' if 'convection' in t else 'Solo Microwave Oven'
    if category == 'Induction Cooktops':
        return 'Infrared Cooktop' if 'infrared' in t else 'Induction Cooktop Push-Button'
    if category == 'Electric Irons' or IRON_WORD_RE.search(t):
        return 'Heavy Weight Dry Iron' if 'heavy' in t else 'Steam Iron Fabric Care'
    if category == 'Electric Kettles':
        return 'Stainless Steel Electric Kettle'
    if category == 'Sewing Machines':
        return 'Manual Composite Sewing Machine' if 'manual' in t else 'Straight Stitch Sewing Frame'
    return 'Appliance Utility Core'


def html_block(rows):
    content = ''.join([f'<tr><th>{compact(k)}</th><td>{compact(v)}</td></tr>' for k, v in rows])
    return compact(f'<table><tbody>{content}</tbody></table>')


def parse_dynamic_attributes_from_html(html_content, category_family=''):
    if not html_content or not isinstance(html_content, str):
        return []

    family = compact(category_family)
    family_prefix_map = {
        'Washing Machines': 'WM',
        'Air Conditioner': 'AC',
        'Water Heaters': 'GY',
    }
    family_prefix = family_prefix_map.get(family, '')

    function_label = 'Function Type'
    capacity_label = 'Capacity'
    if family_prefix:
        function_label = f'{family_prefix} Function Type'
        capacity_label = f'{family_prefix} Capacity'
    if family == 'Washing Machines':
        capacity_label = 'WM Washing Capacity'
    elif family == 'Air Conditioner':
        capacity_label = 'AC Cooling Capacity'
    elif family == 'Water Heaters':
        capacity_label = 'GY Tank Volume'

    li_matches = re.findall(r'<li>(.*?)</li>', html_content, re.IGNORECASE | re.DOTALL)
    parsed_attributes = []
    attribute_name_map = {
        'brand': 'Brand',
        'configuration': function_label,
        'function type': function_label,
        'washing capacity': capacity_label,
        'cooling capacity': capacity_label,
        'storage capacity': capacity_label,
        'tank volume': capacity_label,
        'capacity': capacity_label,
        'power rating': 'Power Rating',
        'rated power': 'Power Rating',
        'water level': 'Water Level',
        'control type': 'Control Type',
    }

    for item in li_matches:
        if ':' not in item:
            continue

        name_part, value_part = item.split(':', 1)
        attr_name = compact(name_part)
        attr_value = compact(value_part).rstrip('.')

        if not attr_name or not attr_value:
            continue

        normalized_name = compact(attribute_name_map.get(attr_name.lower(), attr_name))

        if not normalized_name:
            continue

        parsed_attributes.append((normalized_name, attr_value))

    return parsed_attributes


def build_descriptions(sku, title, brand, category):
    cap_label = capacity_label(category, title)
    cap_value = capacity_value(title, category)
    config = configuration_text(title, category)
    power = wattage(title)
    configuration_points = compact(
        f'<ul class="product-key-features">'
        f'<li>Brand: {brand}.</li>'
        f'<li>{cap_label}: {cap_value}.</li>'
        f'<li>Configuration: {config}.</li>'
        f'<li>Power Rating: {power}.</li>'
        f'</ul>'
    )
    short_desc = html_block([
        ('Brand', brand),
        ('Product SKU', sku),
        (cap_label, cap_value),
        ('Configuration Profile', config),
    ])
    long_desc = html_block([
        ('Brand Designation', brand),
        ('Model Identifier Code', sku),
        ('Title', title),
        ('Categories', category),
        (cap_label, cap_value),
        ('Hardware Configuration', config),
        ('Rated Power Draw', power),
        ('Standard Operational Grid', '230 V / 50 Hz'),
    ])
    return configuration_points, short_desc, long_desc


def template_csv_bytes():
    buffer = io.StringIO()
    pd.DataFrame(columns=REQUIRED_INPUT_COLUMNS).to_csv(buffer, index=False, quoting=1)
    return buffer.getvalue().encode('utf-8')


def split_image_urls(row):
    raw = ''
    if 'image_url' in row and compact(row.get('image_url')):
        raw = row.get('image_url')
    elif 'images' in row and compact(row.get('images')):
        raw = row.get('images')
    elif 'Images' in row and compact(row.get('Images')):
        raw = row.get('Images')
    elif 'url_link' in row and compact(row.get('url_link')):
        raw = row.get('url_link')
    pieces = re.split(r',|<br\s*/?>|\r?\n', str(raw)) if raw is not None else []
    urls = [compact(x) for x in pieces if compact(x)]
    return urls


def download_urls_for_sku(sku, urls):
    root = os.path.join(os.getcwd(), IMAGE_ROOT)
    os.makedirs(root, exist_ok=True)
    # Save all images into a single root folder (no per-SKU subfolders)
    def _fetch(pair):
        index, url = pair
        response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=7)
        response.raise_for_status()
        target = os.path.join(root, f'{sku}_{index}.webp')
        image = Image.open(io.BytesIO(response.content))
        if image.mode not in ('RGB', 'RGBA'):
            image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
        image.save(target, format='WEBP', quality=90, method=6)

    if not urls:
        return

    workers = min(8, max(1, len(urls)))
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_fetch, (i, u)) for i, u in enumerate(urls, start=1)]
        for future in as_completed(futures):
            try:
                future.result()
            except Exception:
                pass


def format_price_output(value):
    if value == '' or value is None:
        return ''
    try:
        number = float(value)
        if number.is_integer():
            return int(number)
        return round(number, 2)
    except Exception:
        return value


def format_regular_price_output(value):
    if value == '' or value is None:
        return ''
    try:
        number = float(value)
        return int(round(number))
    except Exception:
        return value


def require_input_columns(df):
    missing = [col for col in REQUIRED_INPUT_COLUMNS if col not in df.columns]
    if missing:
        raise ValueError('Missing required columns: ' + ', '.join(missing))


def read_uploaded_inventory(uploaded_file):
    file_name = (getattr(uploaded_file, 'name', '') or '').lower()

    if file_name.endswith(('.xlsx', '.xls')):
        return pd.read_excel(io.BytesIO(uploaded_file.getvalue()))

    raw_bytes = uploaded_file.getvalue()
    encodings = ['utf-8-sig', 'utf-8', 'utf-16', 'cp1252', 'latin1']
    separators = [None, ',', ';', '\t', '|']

    for encoding in encodings:
        try:
            decoded_text = raw_bytes.decode(encoding)
        except UnicodeDecodeError:
            continue

        for separator in separators:
            try:
                if separator is None:
                    parsed = pd.read_csv(io.StringIO(decoded_text), sep=None, engine='python')
                else:
                    parsed = pd.read_csv(io.StringIO(decoded_text), sep=separator)

                if len(parsed.columns) > 1 or len(parsed) > 0:
                    return parsed
            except Exception:
                continue

    raise ValueError('Unable to decode uploaded CSV. Save it as UTF-8 or UTF-16 and try again.')


def filter_active_inventory_rows(df):
    candidate_columns = [
        'sku',
        'title',
        'categories',
        'Brands',
        'regular price',
        'sale price',
        'url_link',
        'image_url',
        'Product Configuration',
        'configuration',
        'Images',
    ]
    present_columns = [column for column in candidate_columns if column in df.columns]
    if not present_columns:
        return df.iloc[0:0].copy()

    cleaned = df.copy()
    for column in present_columns:
        cleaned[column] = cleaned[column].map(compact)

    active_mask = cleaned[present_columns].ne('').any(axis=1)
    return cleaned[active_mask].copy()


def process_inventory(df):
    require_input_columns(df)
    working = df.copy()
    working['title'] = working['title'].map(compact)
    working = working[working['title'] != '']

    processed_rows = []
    progress = st.progress(0)
    tracker = st.empty()

    total = len(working)
    for idx, (_, row) in enumerate(working.iterrows(), start=1):
        title = compact(row.get('title'))
        brand = compact(row.get('Brands')) or infer_brand(title)
        category_hierarchy = resolve_product_category(title, row.get('categories'), brand)
        category_family = category_hierarchy.split(' > ', 1)[0]
        sku = prefixed_sku(row.get('sku'), category_family)
        sale_price = number_or_blank(row.get('sale price'))
        regular_price = number_or_blank(row.get('regular price'))
        if regular_price == '' and sale_price != '':
            regular_price = round(float(sale_price) * 1.25, 2)

        tracker.text(f'Compiling and downloading SKU: {sku} ({idx}/{total})')
        progress.progress(idx / max(total, 1))

        urls = split_image_urls(row)
        download_urls_for_sku(sku, urls)

        mapped_count = max(2, len(urls))
        mapped_images = ','.join([f'{MEDIA_BASE}/{sku}_{i}.webp' for i in range(1, mapped_count + 1)])
        config, short_desc, long_desc = build_descriptions(sku, title, brand, category_family)
        dynamic_attrs = parse_dynamic_attributes_from_html(config, category_family)

        output_row = {
            'sku': sku,
            'cross reference tag': f'{brand} | {category_hierarchy.lower().replace(" ", "_")}',
            'configuration': compact(config),
            'short description': compact(short_desc),
            'description': compact(long_desc),
            'title': title,
            'categories': category_hierarchy,
            'regular price': format_regular_price_output(regular_price),
            'sale price': format_price_output(sale_price),
            'Brands': brand,
            '_consolidated_sku': sku,
            'Images': mapped_images,
        }

        for index, (attr_name, attr_value) in enumerate(dynamic_attrs, start=1):
            output_row[f'Attribute {index} name'] = attr_name
            output_row[f'Attribute {index} value(s)'] = attr_value
            output_row[f'Attribute {index} visible'] = '1'
            output_row[f'Attribute {index} global'] = '1'

        processed_rows.append(output_row)

    attribute_columns = []
    for row in processed_rows:
        for key in row.keys():
            if key.startswith('Attribute ') and key not in attribute_columns:
                attribute_columns.append(key)

    def attribute_sort_key(column_name):
        match = re.search(r'Attribute (\d+) (name|value\(s\)|visible|global)', column_name)
        if not match:
            return (10**9, 10**9)
        attribute_index = int(match.group(1))
        field_order = {'name': 0, 'value(s)': 1, 'visible': 2, 'global': 3}[match.group(2)]
        return (attribute_index, field_order)

    ordered_columns = EXPORTED_OUTPUT_COLUMNS + sorted(attribute_columns, key=attribute_sort_key)
    return pd.DataFrame(processed_rows).reindex(columns=ordered_columns)


def main():
    st.set_page_config(page_title='BranchIQ Master Enterprise Engine', layout='wide')
    if 'final_wordpress_df' not in st.session_state:
        st.session_state['final_wordpress_df'] = None

    st.title('BranchIQ Master Enterprise Engine')
    st.download_button(
        label='Download input_template.csv',
        data=template_csv_bytes(),
        file_name='input_template.csv',
        mime='text/csv',
        use_container_width=True,
    )

    uploaded_file = st.file_uploader('Upload inventory CSV', type=['csv'])
    if uploaded_file is not None:
        try:
            incoming = read_uploaded_inventory(uploaded_file)
            total_rows = len(incoming)
            incoming = filter_active_inventory_rows(incoming)
            active_rows = len(incoming)
            st.info(f'Loaded {active_rows} active rows from {total_rows} total rows')
            if total_rows > 0 and active_rows == 0:
                st.warning('The uploaded file has rows, but none contain usable product data in the core columns. If you uploaded the blank template, fill in product rows first.')

            if st.button('Generate file & apply changes', type='primary'):
                try:
                    st.session_state['final_wordpress_df'] = process_inventory(incoming)
                except Exception as exc:
                    st.error(str(exc))
        except Exception as exc:
            st.error(str(exc))

    if st.session_state['final_wordpress_df'] is not None:
        result = st.session_state['final_wordpress_df']
        st.dataframe(result, use_container_width=True)
        buffer = io.StringIO()
        result.to_csv(buffer, index=False, quoting=1)
        st.download_button(
            label='Download wordpress_ready_clean_repaired.csv',
            data=buffer.getvalue(),
            file_name='wordpress_ready_clean_repaired.csv',
            mime='text/csv',
            use_container_width=True,
        )


if __name__ == '__main__':
    main()