import os
import sys
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import compact, infer_category, prefixed_sku, infer_brand, number_or_blank, split_image_urls, download_urls_for_sku, build_descriptions, MEDIA_BASE, EXPORTED_OUTPUT_COLUMNS


def main():
    cwd = Path('.').resolve()
    candidates = ['cleaned_model.csv', 'cleaned_model_recover.csv', 'wordpress_ready.csv']
    input_file = None
    for c in candidates:
        p = cwd / c
        if p.exists():
            input_file = p
            break
    if input_file is None:
        print('No input CSV found. Place cleaned_model.csv in the workspace.')
        return

    print(f'Using input: {input_file}')
    raw_bytes = input_file.read_bytes()
    encodings = ['utf-8-sig', 'utf-8', 'cp1252', 'latin1']
    text = None
    used_enc = None
    for enc in encodings:
        try:
            text = raw_bytes.decode(enc)
            used_enc = enc
            break
        except Exception:
            continue
    if text is None:
        text = raw_bytes.decode('latin1', errors='replace')
        used_enc = 'latin1-replace'
    print(f'Detected encoding: {used_enc}')
    from io import StringIO
    df = pd.read_csv(StringIO(text))
    if 'title' in df.columns:
        df = df.dropna(subset=['title']).copy()
        df['title'] = df['title'].map(compact)
        df = df[df['title'] != '']

    rows = []
    total = len(df)
    for idx, (_, r) in enumerate(df.iterrows(), start=1):
        title = compact(r.get('title'))
        category = infer_category(title, r.get('sku'), r.get('categories'))
        sku = prefixed_sku(r.get('sku'), category)
        brand = compact(r.get('Brands')) or infer_brand(title)
        sale_price = number_or_blank(r.get('sale price'))
        regular_price = number_or_blank(r.get('regular price'))
        if regular_price == '' and sale_price != '':
            try:
                regular_price = round(float(sale_price) * 1.25, 2)
            except Exception:
                regular_price = ''

        print(f'[{idx}/{total}] Processing SKU: {sku}')
        urls = split_image_urls(r)
        try:
            download_urls_for_sku(sku, urls)
        except Exception:
            pass

        mapped_count = max(2, len(urls))
        images = ','.join([f'{MEDIA_BASE}/{sku}_{i}.webp' for i in range(1, mapped_count + 1)])
        bullets, short_desc, long_desc = build_descriptions(sku, title, brand, category)
        rows.append({
            'sku': sku,
            'cross reference tag': f"{brand} | {category.lower().replace(' ', '_')}",
            'configuration': compact(bullets),
            'short description': compact(short_desc),
            'description': compact(long_desc),
            'title': title,
            'categories': category,
            'regular price': regular_price,
            'sale price': sale_price,
            'Brands': brand,
            '_consolidated_sku': sku,
            'Images': images,
        })

    out = pd.DataFrame(rows, columns=EXPORTED_OUTPUT_COLUMNS)
    out_path = cwd / 'wordpress_ready_clean_repaired.csv'
    out.to_csv(out_path, index=False, quoting=1)
    print(f'Wrote output: {out_path} ({len(out)} rows)')


if __name__ == '__main__':
    main()
