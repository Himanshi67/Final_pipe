"""Production-ready WooCommerce automation engine.

This module reads a CSV or Excel inventory file, consolidates split-component
SKUs, fetches product pages with requests, and emits WooCommerce-ready HTML for
description, short description, and configuration blocks.
"""

from __future__ import annotations

import argparse
import math
import json
import html
import os
import re
import time
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

import pandas as pd
import requests
from bs4 import BeautifulSoup
from requests import Response


DEFAULT_INPUT_FILE = "cleaned_model.csv"
DEFAULT_OUTPUT_FILE = "woo_final_product_upload.csv"
DEFAULT_IMAGE_DIR = "wp_product_images"
DEFAULT_TIMEOUT = 15
DEFAULT_DELAY = 1.0
DEFAULT_RETRY_COUNT = 3
DEFAULT_BACKOFF_SECONDS = 1.5
MAX_IMAGES = 3

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}

BRAND_PREFIXES = (
    "WHIRLPOOL",
    "HAIER",
    "SAMSUNG",
    "VOLTAS",
    "LG",
    "GODREJ",
    "KENSTAR",
    "USHA",
    "IFB",
    "CROMA",
)

NOISE_PATTERNS = (
    r"share this product",
    r"add to wishlist",
    r"free delivery",
    r"emi starts at",
    r"emi starting at",
    r"easy emi",
    r"inclusive of all taxes",
    r"add to cart",
    r"buy now",
    r"view more",
    r"related products",
    r"related items",
)

SHORT_DESCRIPTION_KEY_HINTS = (
    "model name",
    "model",
    "capacity",
    "star rating",
    "rating",
    "colour",
    "color",
    "brand",
    "type",
    "warranty",
)

CONFIGURATION_SELECTORS = (
    "div.features li",
    "div.highlights li",
    "section.features li",
    "section.highlights li",
    "ul.features li",
    "ul.highlights li",
    "div[class*='feature'] li",
    "div[class*='highlight'] li",
)

SHORT_DESCRIPTION_SELECTORS = (
    "div[class*='summary']",
    "div[class*='grid']",
    "div[class*='details']",
    "div[class*='spec']",
    "section[class*='summary']",
    "section[class*='grid']",
)

FULL_DESCRIPTION_SELECTORS = (
    "table",
    "div.spec-table",
    "div[class*='spec-table']",
    "section[class*='spec'] table",
    "div[class*='spec'] table",
)

BRAND_ROUTING_SELECTORS = {
    "samsung": {
        "full": (
            "div.specs-table",
            "div.spec-table",
            "div.product-specifications",
            "section.specifications",
            "section[class*='spec'] table",
        ),
        "short": (
            "div.product-summary",
            "div.summary-grid",
            "div.overview-grid",
            "div[class*='summary']",
        ),
        "config": (
            "div.features li",
            "div.highlights li",
            "ul.features li",
            "ul.highlights li",
        ),
        "images": (
            "div.product-gallery img",
            "div.gallery img",
            "img.main-prod-img",
            "img.product-image",
        ),
        "price": (
            "meta[itemprop='price']",
            "meta[property='product:price:amount']",
            "span.price",
            "div.price",
        ),
    },
    "haier": {
        "full": (
            "div.spec-table",
            "div.specification-table",
            "div.product-specification",
            "section.specification",
            "table.spec-table",
        ),
        "short": (
            "div.features-grid",
            "div.spec-summary",
            "div.key-specs",
            "div[class*='summary']",
        ),
        "config": (
            "div.features li",
            "div.highlights li",
            "ul.features li",
            "ul.highlights li",
        ),
        "images": (
            "div.product-gallery img",
            "div.gallery img",
            "img.detail-image",
            "img.product-image",
        ),
        "price": (
            "meta[itemprop='price']",
            "meta[property='product:price:amount']",
            "span.price",
            "div.price",
        ),
    },
    "voltas": {
        "full": (
            "div.spec-table",
            "div.technical-specifications",
            "div.product-specifications",
            "section.specifications",
            "table.spec-table",
        ),
        "short": (
            "div.product-summary",
            "div.summary-grid",
            "div.key-details",
            "div[class*='summary']",
        ),
        "config": (
            "div.features li",
            "div.highlights li",
            "ul.features li",
            "ul.highlights li",
        ),
        "images": (
            "div.product-gallery img",
            "div.gallery img",
            "img.main-prod-img",
            "img.product-image",
        ),
        "price": (
            "meta[itemprop='price']",
            "meta[property='product:price:amount']",
            "span.price",
            "div.price",
        ),
    },
}


@dataclass
class FetchOptions:
    proxy_service: str = ""
    api_key: str = ""
    render_js: bool = False
    retries: int = DEFAULT_RETRY_COUNT
    timeout: int = DEFAULT_TIMEOUT
    backoff_seconds: float = DEFAULT_BACKOFF_SECONDS


def build_proxy_request_url(url: str, options: FetchOptions) -> str:
    if not options.proxy_service or not options.api_key:
        return url

    target = quote(url, safe="")
    service = options.proxy_service.strip().casefold()

    if service == "scraperapi":
        render_value = "true" if options.render_js else "false"
        return f"https://api.scraperapi.com/?api_key={options.api_key}&url={target}&render={render_value}"

    if service == "scrapingbee":
        render_value = "true" if options.render_js else "false"
        return f"https://app.scrapingbee.com/api/v1/?api_key={options.api_key}&url={target}&render_js={render_value}"

    return url


def fetch_url(url: str, options: FetchOptions, session: requests.Session | None = None) -> Response | None:
    active_session = session or requests.Session()
    request_url = build_proxy_request_url(url, options)
    last_error: Exception | None = None

    for attempt in range(1, max(1, options.retries) + 1):
        try:
            response = active_session.get(request_url, headers=HEADERS, timeout=options.timeout)
            if response.status_code == 200 and response.text.strip():
                return response
            last_error = RuntimeError(f"Unexpected status {response.status_code}")
        except (requests.RequestException, RuntimeError) as exc:  # pyright: ignore[reportGeneralTypeIssues]  # pragma: no cover - runtime/network dependent
            last_error = exc

        if attempt < options.retries:
            time.sleep(options.backoff_seconds * attempt)

    if last_error:
        print(f"   [Error] Fetch failed for {url}: {last_error}")
    return None


@dataclass
class ProductRecord:
    busy_item_detail: str = ""
    woo_sku: str = ""
    product_name: str = ""
    cross_reference_tag: str = ""
    regular_price: str = ""
    sale_price: str = ""
    product_description: str = ""
    product_short_description: str = ""
    product_configuration: str = ""
    images: str = ""
    gallery_images: str = ""

    def merge_from(self, other: "ProductRecord") -> None:
        self.busy_item_detail = merge_texts(self.busy_item_detail, other.busy_item_detail)
        self.cross_reference_tag = merge_texts(self.cross_reference_tag, other.cross_reference_tag, delimiter=" | ")
        self.product_name = self.product_name or other.product_name
        self.regular_price = self.regular_price or other.regular_price
        self.sale_price = self.sale_price or other.sale_price
        self.product_description = self.product_description or other.product_description
        self.product_short_description = self.product_short_description or other.product_short_description
        self.product_configuration = self.product_configuration or other.product_configuration
        self.images = merge_csv_values(self.images, other.images)
        self.gallery_images = merge_csv_values(self.gallery_images, other.gallery_images)


def merge_texts(*values: str, delimiter: str = " | ") -> str:
    cleaned: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in cleaned:
            cleaned.append(text)
    return delimiter.join(cleaned)


def merge_csv_values(*values: str) -> str:
    merged: list[str] = []
    for value in values:
        if not value:
            continue
        for part in str(value).split(","):
            text = part.strip()
            if text and text not in merged:
                merged.append(text)
    return ",".join(merged)


def read_input_dataframe(path: str) -> pd.DataFrame:
    suffix = Path(path).suffix.lower()
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin1"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except UnicodeDecodeError:
            continue
    return pd.read_csv(path, encoding="latin1")


def normalize_input_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    aliases = {
        "item details": "Item Details",
        "item detail": "Item Details",
        "busy item detail": "Item Details",
        "title": "title",
        "name": "Item Details",
        "url": "URL",
        "source url": "URL",
        "source_url": "URL",
        "specification": "URL",
        "images": "Images",
        "image": "Images",
        "gallery images": "Images",
        "regular price": "regular price",
        "sale price": "sale price",
        "sku": "sku",
    }

    normalized = pd.DataFrame(index=df.index)
    for index, column in enumerate(df.columns):
        raw_name = str(column).strip()
        canonical_name = aliases.get(raw_name.casefold(), raw_name)
        series = df.iloc[:, index]

        if canonical_name not in normalized.columns:
            normalized[canonical_name] = series
            continue

        existing = normalized[canonical_name]
        blank_mask = (
            existing.isna()
            | (existing.astype(str).str.strip() == "")
            | (existing.astype(str).str.lower() == "nan")
        )
        normalized[canonical_name] = existing.where(~blank_mask, series)

    if "Item Details" not in normalized.columns and "sku" in normalized.columns:
        normalized["Item Details"] = normalized["sku"]

    if "Item Details" not in normalized.columns and "title" in normalized.columns:
        normalized["Item Details"] = normalized["title"]

    return normalized


def clean_and_build_sku(busy_item_string: Any) -> tuple[str, str]:
    raw_string = str(busy_item_string or "").strip()

    cleaned = re.sub(
        r"^(WHIRLPOOL|HAIER|SAMSUNG|VOLTAS|LG|GODREJ|KENSTAR|USHA|IFB|CROMA)-",
        "",
        raw_string,
        flags=re.IGNORECASE,
    )
    cleaned = re.sub(r"\((INNER|OUTER|INV|IDU|ODU|INDOOR|OUTDOOR)\)", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\b(INNER|OUTER|INDOOR|OUTDOOR|IDU|ODU)\b", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\(.*?\)", "", cleaned)
    cleaned = re.sub(r"[^A-Za-z0-9]", "", cleaned)
    return raw_string, cleaned.upper()


def normalize_product_name(raw_busy_name: str) -> str:
    name = str(raw_busy_name or "").strip()
    if not name:
        return ""
    name = re.sub(r"\(.*?\)", "", name)
    name = name.replace("-", " ")
    name = re.sub(r"\s+", " ", name).strip()
    return name


def clean_scraped_text(text: str) -> str:
    if not text:
        return ""

    lines = [line.strip() for line in str(text).splitlines() if line.strip()]
    cleaned_lines: list[str] = []
    for line in lines:
        if any(re.search(pattern, line, re.IGNORECASE) for pattern in NOISE_PATTERNS):
            continue
        cleaned_lines.append(line)
    return " ".join(cleaned_lines)


def is_noise_text(value: str) -> bool:
    text = str(value or "").strip().casefold()
    if not text:
        return True
    return any(phrase in text for phrase in ("share", "wishlist", "add to cart", "buy now", "compare", "emi"))


def is_short_description_key(key: str) -> bool:
    normalized = str(key or "").strip().casefold()
    return any(hint in normalized for hint in SHORT_DESCRIPTION_KEY_HINTS)


def get_brand_from_url(url: str) -> str:
    lower = str(url or "").casefold()
    for brand in BRAND_ROUTING_SELECTORS:
        if brand in lower:
            return brand
    return ""


def extract_best_src(image_tag: Any) -> str:
    for attr in ("data-src", "data-lazy-src", "src"):
        value = image_tag.get(attr)
        if value:
            return str(value).strip()
    srcset = image_tag.get("srcset")
    if srcset:
        candidate = srcset.split(",")[0].strip().split(" ")[0]
        return candidate.strip()
    return ""


def looks_like_product_image(url: str) -> bool:
    lower = str(url or "").lower()
    if not lower.startswith("http"):
        return False
    if any(token in lower for token in ("icon", "logo", "sprite", "share", "star", "wishlist", "cart", "avatar")):
        return False
    return bool(re.search(r"\.(jpg|jpeg|png|webp|gif)(\?|$)", lower) or any(host in lower for host in ("amazon", "flipkart", "samsung", "haier", "godrej", "croma")))


def strip_urls_from_text(value: str) -> str:
    if not value:
        return ""
    cleaned = re.sub(r"https?://\S+", "", str(value))
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def parse_price_text(text: str) -> float | None:
    if not text:
        return None
    match = re.search(r"[₹Rs$€]\s*([0-9,]+(?:\.[0-9]+)?)", str(text))
    if not match:
        match = re.search(r"\b([0-9,]+(?:\.[0-9]+)?)\b", str(text))
    if not match:
        return None
    try:
        return float(match.group(1).replace(",", ""))
    except ValueError:
        return None


def normalize_price_value(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return ""
    parsed = parse_price_text(text)
    if parsed is None:
        return ""
    return str(int(parsed))


def price_fallback_from_sale(regular_price: str, sale_price: str) -> str:
    regular_norm = normalize_price_value(regular_price)
    sale_norm = normalize_price_value(sale_price)
    if regular_norm:
        return regular_norm
    if sale_norm:
        try:
            return str(int(math.ceil(float(sale_norm) * 1.25)))
        except ValueError:
            return sale_norm
    return ""


def extract_prices_from_soup(soup: BeautifulSoup) -> tuple[str, str]:
    regular = ""
    sale = ""

    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text(strip=True)
        if not raw:
            continue
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        candidates = payload if isinstance(payload, list) else [payload]
        for item in candidates:
            if not isinstance(item, dict):
                continue
            offers = item.get("offers") or item.get("offer")
            if isinstance(offers, dict):
                price_val = offers.get("price")
                if price_val:
                    sale = sale or normalize_price_value(price_val)
                high_price = offers.get("highPrice") or offers.get("originalPrice")
                if high_price:
                    regular = regular or normalize_price_value(high_price)
            elif isinstance(offers, list):
                for offer in offers:
                    if not isinstance(offer, dict):
                        continue
                    price_val = offer.get("price")
                    if price_val:
                        sale = sale or normalize_price_value(price_val)
                    high_price = offer.get("highPrice") or offer.get("originalPrice")
                    if high_price:
                        regular = regular or normalize_price_value(high_price)

    meta_price_nodes = (
        soup.find(attrs={"itemprop": "price"}),
        soup.find(attrs={"property": "product:price:amount"}),
        soup.find(attrs={"name": "price"}),
    )
    for node in meta_price_nodes:
        if not node:
            continue
        text = node.get("content") or node.get_text(" ", strip=True)
        parsed = normalize_price_value(text)
        if parsed:
            sale = sale or parsed

    return regular, sale


def extract_price_from_visible_text(soup: BeautifulSoup) -> tuple[str, str]:
    regular = ""
    sale = ""
    price_labels = ("mrp", "price", "selling price", "offer price", "deal price", "our price", "sale price")

    for node in soup.find_all(True):
        label = node.get_text(" ", strip=True)
        lower = label.casefold()
        if not any(price_label in lower for price_label in price_labels):
            continue
        matches = re.findall(r"[₹Rs$€]?\s*[0-9][0-9,]*(?:\.[0-9]+)?", label)
        values = [normalize_price_value(match) for match in matches]
        values = [value for value in values if value]
        if not values:
            continue
        sale = sale or values[0]
        if len(values) > 1:
            regular = regular or values[-1]
        if regular and sale:
            break

    return regular, sale


def extract_prices(soup: BeautifulSoup) -> tuple[str, str]:
    regular, sale = extract_prices_from_soup(soup)
    if not regular or not sale:
        visible_regular, visible_sale = extract_price_from_visible_text(soup)
        regular = regular or visible_regular
        sale = sale or visible_sale
    return regular, sale


def extract_pairs_from_table(table: Any) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for row in table.find_all("tr"):
        cells = row.find_all(["th", "td"])
        if len(cells) < 2:
            continue
        key = strip_urls_from_text(cells[0].get_text(" ", strip=True))
        value = strip_urls_from_text(cells[1].get_text(" ", strip=True))
        if not key or not value:
            continue
        if is_noise_text(key) or is_noise_text(value):
            continue
        pairs.setdefault(key, value)
    return pairs


def extract_pairs_from_definition_list(dl: Any) -> dict[str, str]:
    pairs: dict[str, str] = {}
    terms = dl.find_all(["dt", "dd"])
    for index in range(0, len(terms) - 1, 2):
        key = strip_urls_from_text(terms[index].get_text(" ", strip=True))
        value = strip_urls_from_text(terms[index + 1].get_text(" ", strip=True))
        if key and value and not is_noise_text(key) and not is_noise_text(value):
            pairs.setdefault(key, value)
    return pairs


def extract_pairs_from_row_container(container: Any) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for row in container.find_all(True, recursive=True):
        text = strip_urls_from_text(row.get_text(" ", strip=True))
        if not text or ":" not in text:
            continue
        key, value = [segment.strip() for segment in text.split(":", 1)]
        if key and value and not is_noise_text(key) and not is_noise_text(value):
            pairs.setdefault(key, value)
    return pairs


def extract_selector_key_value_pairs(soup: BeautifulSoup, selectors: tuple[str, ...], max_items: int = 4) -> dict[str, str]:
    pairs: dict[str, str] = {}
    for selector in selectors:
        for container in soup.select(selector):
            candidate_pairs: dict[str, str] = {}
            if container.name == "table":
                candidate_pairs = extract_pairs_from_table(container)
            elif container.name == "dl":
                candidate_pairs = extract_pairs_from_definition_list(container)
            else:
                candidate_pairs = extract_pairs_from_table(container)
                if not candidate_pairs:
                    candidate_pairs = extract_pairs_from_row_container(container)

            for key, value in candidate_pairs.items():
                if key not in pairs:
                    pairs[key] = value
                if len(pairs) >= max_items:
                    return pairs
    return pairs


def extract_configuration_bullets(soup: BeautifulSoup, selectors: tuple[str, ...] | None = None) -> list[str]:
    bullets: list[str] = []
    active_selectors = selectors or CONFIGURATION_SELECTORS
    for selector in active_selectors:
        for node in soup.select(selector):
            text = clean_scraped_text(node.get_text(" ", strip=True))
            if not text or is_noise_text(text):
                continue
            if text not in bullets:
                bullets.append(text)
            if len(bullets) >= 4:
                return bullets[:4]
    return bullets[:4]


def extract_short_description_specs(
    soup: BeautifulSoup,
    full_specs: dict[str, str],
    selectors: tuple[str, ...] | None = None,
) -> dict[str, str]:
    active_selectors = selectors or SHORT_DESCRIPTION_SELECTORS
    short_specs = extract_selector_key_value_pairs(soup, active_selectors, max_items=4)
    if short_specs:
        filtered = {key: value for key, value in short_specs.items() if is_short_description_key(key)}
        if filtered:
            return filtered

    filtered = {}
    for key, value in full_specs.items():
        if is_short_description_key(key):
            filtered[key] = value
        if len(filtered) >= 4:
            break
    return filtered


def extract_full_description_specs(soup: BeautifulSoup, selectors: tuple[str, ...] | None = None) -> dict[str, str]:
    specs: dict[str, str] = {}
    active_selectors = selectors or FULL_DESCRIPTION_SELECTORS
    for selector in active_selectors:
        for container in soup.select(selector):
            if container.name == "table":
                candidate = extract_pairs_from_table(container)
            elif container.name == "dl":
                candidate = extract_pairs_from_definition_list(container)
            else:
                candidate = extract_pairs_from_table(container)
                if not candidate:
                    candidate = extract_pairs_from_row_container(container)

            for key, value in candidate.items():
                if key not in specs:
                    specs[key] = value
                if len(specs) >= 60:
                    return specs
    return specs


def extract_brand_specific_content(soup: BeautifulSoup, brand: str) -> dict[str, Any]:
    route = BRAND_ROUTING_SELECTORS.get(brand, {})
    full_specs = extract_full_description_specs(soup, route.get("full"))
    short_specs = extract_short_description_specs(soup, full_specs, route.get("short"))
    highlights = extract_configuration_bullets(soup, route.get("config"))
    images = extract_image_urls(soup, route.get("images"))
    return {
        "specifications": full_specs,
        "short_specs": short_specs,
        "highlights": highlights,
        "images": images,
    }


def extract_generic_content(soup: BeautifulSoup) -> dict[str, Any]:
    full_specs = extract_full_description_specs(soup)
    if not full_specs:
        full_specs = {}
        for table in soup.find_all("table"):
            full_specs.update(extract_pairs_from_table(table))

    short_specs = extract_short_description_specs(soup, full_specs)
    highlights = extract_configuration_bullets(soup)
    images = extract_image_urls(soup)
    return {
        "specifications": full_specs,
        "short_specs": short_specs,
        "highlights": highlights,
        "images": images,
    }


def extract_summary_sentences(description_text: str) -> list[str]:
    cleaned = clean_scraped_text(description_text)
    if not cleaned:
        return []

    sentences: list[str] = []
    for sentence in re.split(r"[.?!]+", cleaned):
        text = sentence.strip()
        if len(text.split()) < 4:
            continue
        if is_noise_text(text):
            continue
        sentences.append(text)
        if len(sentences) >= 4:
            break
    return sentences


def build_product_description_table(specs_dict: dict[str, str], fallback_text: str = "") -> str:
    if not specs_dict:
        if not fallback_text:
            return ""
        sentence_rows = [s.strip() for s in fallback_text.split(".") if len(s.strip()) > 10][:6]
        specs_dict = {f"Feature {index + 1}": sentence for index, sentence in enumerate(sentence_rows)}
        if not specs_dict:
            return ""

    html_output = '<table class="woocommerce-product-attributes shop_attributes" style="width:100%; border-collapse: collapse; margin-top:15px;">'
    toggle = True
    for key, value in specs_dict.items():
        bg_color = "#f9f9f9" if toggle else "#ffffff"
        html_output += f'<tr class="woocommerce-product-attributes-item" style="background-color: {bg_color};">'
        html_output += f'  <th class="woocommerce-product-attributes-item__label" style="text-align:left; padding:10px; border:1px solid #e2e2e2; font-weight:600; width:35%;">{html.escape(str(key))}</th>'
        html_output += f'  <td class="woocommerce-product-attributes-item__value" style="padding:10px; border:1px solid #e2e2e2;">{html.escape(str(value))}</td>'
        html_output += "</tr>"
        toggle = not toggle
    html_output += "</table>"
    return html_output


def build_product_short_description_table(short_specs_dict: dict[str, str], fallback_text: str = "") -> str:
    if not short_specs_dict:
        fallback_sentences = extract_summary_sentences(fallback_text)
        if fallback_sentences:
            short_specs_dict = {
                "Overview": fallback_sentences[0]
            }
            if len(fallback_sentences) > 1:
                short_specs_dict["Detail"] = fallback_sentences[1]
        else:
            return ""

    html_output = '<table class="short-spec-table" style="width:100%; border: 1px solid #ddd; border-radius: 4px; border-collapse: collapse; font-size:14px; margin-bottom:10px;">'
    for key, value in short_specs_dict.items():
        html_output += "<tr>"
        html_output += f'  <td style="padding: 8px; font-weight: bold; color:#555; background-color:#f1f1f1; border-bottom: 1px solid #ddd; width:40%;">{html.escape(str(key))}:</td>'
        html_output += f'  <td style="padding: 8px; border-bottom: 1px solid #ddd; color:#333;">{html.escape(str(value))}</td>'
        html_output += "</tr>"
    html_output += "</table>"
    return html_output


def build_product_configuration_bullets(highlights_list: list[str], fallback_text: str = "") -> str:
    bullets = [clean_scraped_text(item) for item in highlights_list if str(item).strip()]
    bullets = [bullet for bullet in bullets if bullet and not is_noise_text(bullet)]

    if not bullets and fallback_text:
        bullets = [sentence.strip() for sentence in fallback_text.split(".") if len(sentence.strip()) > 15]

    bullets = bullets[:4]
    while len(bullets) < 3:
        bullets.append("Authorised product sourced for ecommerce publishing.")

    html_output = '<ul class="product-key-features" style="padding-left:20px; margin-top:5px; margin-bottom:5px; line-height:1.6;">'
    for bullet in bullets[:4]:
        text = bullet.rstrip(".")
        html_output += f'<li style="margin-bottom:6px; color:#444;">{html.escape(text)}.</li>'
    html_output += "</ul>"
    return html_output


def build_cross_reference_tag(original_sku: str, consolidated_sku: str, raw_title: str) -> str:
    pieces = [str(original_sku or "").strip(), str(raw_title or "").strip()]
    if consolidated_sku and consolidated_sku != original_sku:
        pieces.append(f"base:{consolidated_sku}")
    return " :: ".join([piece for piece in pieces if piece])


def download_and_standardize_image(
    image_url: str,
    woo_sku: str,
    index: int = 0,
    image_dir: str = DEFAULT_IMAGE_DIR,
    fetch_options: FetchOptions | None = None,
    session: requests.Session | None = None,
) -> str:
    if not image_url or pd.isna(image_url):
        return ""

    try:
        response = fetch_url(image_url, fetch_options or FetchOptions(), session=session)
        if response is None:
            return ""

        content_type = response.headers.get("content-type", "").lower()
        ext = "jpg"
        if "png" in content_type:
            ext = "png"
        elif "webp" in content_type:
            ext = "webp"
        elif "gif" in content_type:
            ext = "gif"
        else:
            path_ext = Path(urlparse(image_url).path).suffix.lower().lstrip(".")
            if path_ext in {"jpg", "jpeg", "png", "webp", "gif"}:
                ext = "jpg" if path_ext == "jpeg" else path_ext

        suffix = "-main" if index == 0 else f"-alt{index}"
        filename = f"{woo_sku.lower()}{suffix}.{ext}"
        filepath = Path(image_dir) / filename
        filepath.parent.mkdir(parents=True, exist_ok=True)

        with open(filepath, "wb") as file_handle:
            file_handle.write(response.content)
        return filename
    except (requests.RequestException, OSError, ValueError) as exc:  # pyright: ignore[reportGeneralTypeIssues]  # pragma: no cover - network and file IO guarded by runtime
        print(f"   [Warning] Image download failed for {image_url}: {exc}")
        return ""


def extract_image_urls(soup: BeautifulSoup, selectors: tuple[str, ...] | None = None) -> list[str]:
    urls: list[str] = []
    active_selectors = selectors or (
        "div.product-gallery img",
        "div.gallery img",
        "div.images img",
        "img.main-prod-img",
        "img.product-image",
        "img",
    )
    for selector in active_selectors:
        for image_tag in soup.select(selector):
            src = extract_best_src(image_tag)
            if not src or not looks_like_product_image(src):
                continue
            if src not in urls:
                urls.append(src)
            if len(urls) >= MAX_IMAGES:
                return urls[:MAX_IMAGES]
    return urls[:MAX_IMAGES]


def parse_url_to_raw_components(
    url: str,
    fetch_options: FetchOptions,
    session: requests.Session | None = None,
) -> dict[str, Any] | None:
    try:
        response = fetch_url(url, fetch_options, session=session)
        if response is None:
            return None
        soup = BeautifulSoup(response.content, "html.parser")
        brand = get_brand_from_url(url)

        brand_extracted = extract_brand_specific_content(soup, brand) if brand else {}
        generic_extracted = extract_generic_content(soup)

        extracted = {
            "specifications": brand_extracted.get("specifications") or generic_extracted.get("specifications") or {},
            "short_specs": brand_extracted.get("short_specs") or generic_extracted.get("short_specs") or {},
            "highlights": brand_extracted.get("highlights") or generic_extracted.get("highlights") or [],
            "images": brand_extracted.get("images") or generic_extracted.get("images") or [],
        }

        full_specs = dict(extracted.get("specifications", {}) or {})
        short_specs = dict(extracted.get("short_specs", {}) or {})
        highlights = list(extracted.get("highlights", []) or [])
        images = list(extracted.get("images", []) or [])

        fallback_text = ""
        meta_description = soup.find("meta", attrs={"name": "description"})
        if meta_description and meta_description.get("content"):
            fallback_text = str(meta_description.get("content", "")).strip()

        if not fallback_text:
            fallback_text = clean_scraped_text(soup.get_text("\n", strip=True))

        regular_price, sale_price = extract_prices(soup)

        return {
            "specifications": full_specs,
            "short_specs": short_specs,
            "highlights": highlights,
            "images": images,
            "fallback_text": fallback_text,
            "brand": brand,
            "regular_price": regular_price,
            "sale_price": sale_price,
        }
    except (requests.RequestException, ValueError, AttributeError) as exc:  # pyright: ignore[reportGeneralTypeIssues]  # pragma: no cover - network errors depend on target site
        print(f"   [Error] General parser breakage on URL {url}: {exc}")
        return None


def extract_selector_content(
    url: str,
    fetch_options: FetchOptions,
    session: requests.Session | None = None,
) -> dict[str, Any] | None:
    return parse_url_to_raw_components(url, fetch_options, session=session)


def choose_source_url(row: pd.Series) -> str:
    for column in ("URL", "source_url", "Specification", "Specification ", "specification"):
        value = str(row.get(column, "")).strip()
        if value and value.lower() != "nan":
            match = re.search(r"https?://[^\s,\"]+", value)
            if match:
                return match.group(0)
    return ""


def extract_input_images(row: pd.Series) -> list[str]:
    for column in ("Images", "images", "Gallery Images"):
        value = str(row.get(column, "")).strip()
        if not value or value.lower() == "nan":
            continue
        urls = [part.strip() for part in value.split(",") if part.strip()]
        if urls:
            return urls
    return []


def make_short_specs(full_specs: dict[str, str], fallback_text: str) -> dict[str, str]:
    short_specs: dict[str, str] = {}
    for key in ("Model Name", "Capacity", "Star Rating", "Color"):
        match_value = next(
            (value for spec_key, value in full_specs.items() if key.casefold() in spec_key.casefold()),
            "Refer Specs",
        )
        short_specs[key] = match_value
    if all(value == "Refer Specs" for value in short_specs.values()):
        fallback_sentences = extract_summary_sentences(fallback_text)
        if fallback_sentences:
            short_specs = {"Overview": fallback_sentences[0]}
            if len(fallback_sentences) > 1:
                short_specs["Detail"] = fallback_sentences[1]
    return short_specs


def combine_records(existing: ProductRecord, incoming: ProductRecord) -> ProductRecord:
    merged = ProductRecord(**existing.__dict__)
    merged.merge_from(incoming)
    return merged


def execute_shree_jee_scraper_pipeline(
    input_path: str,
    image_dir: str = DEFAULT_IMAGE_DIR,
    delay: float = DEFAULT_DELAY,
    fetch_options: FetchOptions | None = None,
) -> pd.DataFrame:
    print(f"[Start] Initializing inventory processing from file: {input_path}")
    raw_df = read_input_dataframe(input_path)
    raw_df = normalize_input_dataframe(raw_df)

    active_fetch_options = fetch_options or FetchOptions()
    session = requests.Session()

    consolidation: OrderedDict[str, ProductRecord] = OrderedDict()

    try:
        for row_number, (_, row) in enumerate(raw_df.iterrows(), start=1):
            raw_sku = str(row.get("sku", "")).strip()
            raw_title = str(row.get("title", "")).strip()
            raw_busy_name = str(row.get("Item Details", "")).strip()
            if not raw_busy_name or raw_busy_name.lower() == "nan":
                raw_busy_name = raw_sku or raw_title
            if not raw_busy_name:
                continue

            sku_seed = raw_sku or raw_busy_name
            busy_raw_text, clean_woo_sku = clean_and_build_sku(sku_seed)
            if not clean_woo_sku:
                continue

            product_name_seed = raw_title or raw_busy_name

            existing_regular_price = normalize_price_value(row.get("regular price", ""))
            existing_sale_price = normalize_price_value(row.get("sale price", ""))

            source_url = choose_source_url(row)
            input_images = extract_input_images(row)
            if source_url:
                scraped_payload = extract_selector_content(source_url, active_fetch_options, session=session)
                time.sleep(delay)
            else:
                scraped_payload = None

            if not scraped_payload:
                scraped_payload = {
                    "specifications": {},
                    "short_specs": {},
                    "highlights": [],
                    "images": input_images,
                    "fallback_text": f"Premium model {raw_busy_name} available at Shree Jee Electronics showrooms.",
                }

            full_specs = dict(scraped_payload.get("specifications", {}) or {})
            fallback_text = str(scraped_payload.get("fallback_text", "") or "")
            short_specs = dict(scraped_payload.get("short_specs", {}) or {})
            highlights = list(scraped_payload.get("highlights", []) or [])
            images = list(scraped_payload.get("images", []) or [])
            scraped_regular_price = normalize_price_value(scraped_payload.get("regular_price", ""))
            scraped_sale_price = normalize_price_value(scraped_payload.get("sale_price", ""))

            if input_images:
                images = input_images
            elif not images:
                images = extract_input_images(row)

            short_specs = make_short_specs(full_specs, fallback_text)

            sale_price_value = existing_sale_price or scraped_sale_price
            regular_price_value = existing_regular_price or scraped_regular_price or price_fallback_from_sale("", sale_price_value)
            if not regular_price_value and sale_price_value:
                regular_price_value = price_fallback_from_sale("", sale_price_value)

            html_desc = build_product_description_table(full_specs, fallback_text)
            html_short_desc = build_product_short_description_table(short_specs, fallback_text)
            html_config = build_product_configuration_bullets(highlights, fallback_text)

            local_images_list: list[str] = []
            for img_index, image_url in enumerate(images[:MAX_IMAGES]):
                local_image_name = download_and_standardize_image(
                    image_url,
                    clean_woo_sku,
                    img_index,
                    image_dir=image_dir,
                    fetch_options=active_fetch_options,
                    session=session,
                )
                if local_image_name:
                    local_images_list.append(local_image_name)

            primary_image_reference = local_images_list[0] if local_images_list else "placeholder.jpg"
            gallery_images_reference = ",".join(local_images_list[1:]) if len(local_images_list) > 1 else ""

            record = ProductRecord(
                busy_item_detail=busy_raw_text,
                woo_sku=clean_woo_sku,
                product_name=normalize_product_name(product_name_seed),
                cross_reference_tag=build_cross_reference_tag(busy_raw_text, clean_woo_sku, normalize_product_name(product_name_seed)),
                regular_price=regular_price_value,
                sale_price=sale_price_value,
                product_description=html_desc,
                product_short_description=html_short_desc,
                product_configuration=html_config,
                images=primary_image_reference,
                gallery_images=gallery_images_reference,
            )

            if clean_woo_sku in consolidation:
                consolidation[clean_woo_sku] = combine_records(consolidation[clean_woo_sku], record)
            else:
                consolidation[clean_woo_sku] = record

            print(f"Processing row {row_number}: {clean_woo_sku}")
    finally:
        session.close()

    final_output_df = pd.DataFrame([record.__dict__ for record in consolidation.values()])
    final_output_df.rename(
        columns={
            "busy_item_detail": "BUSY Item Detail",
            "woo_sku": "WooCommerce SKU",
            "product_name": "Product Name",
            "regular_price": "regular price",
            "sale_price": "sale price",
            "cross_reference_tag": "cross reference tag",
            "product_description": "product description",
            "product_short_description": "product short description",
            "product_configuration": "product configuration",
            "images": "Images",
            "gallery_images": "Gallery Images",
        },
        inplace=True,
    )

    priority = [
        "BUSY Item Detail",
        "WooCommerce SKU",
        "cross reference tag",
        "Product Name",
        "regular price",
        "sale price",
        "product short description",
        "product description",
        "product configuration",
        "Images",
        "Gallery Images",
    ]
    ordered_columns = [column for column in priority if column in final_output_df.columns]
    ordered_columns.extend([column for column in final_output_df.columns if column not in ordered_columns])
    final_output_df = final_output_df[ordered_columns]
    return final_output_df


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Production-ready Shree Jee automation engine")
    parser.add_argument("--input", default=DEFAULT_INPUT_FILE, help="Input CSV or Excel inventory file")
    parser.add_argument("--output", default=DEFAULT_OUTPUT_FILE, help="Output CSV path")
    parser.add_argument("--image-dir", default=DEFAULT_IMAGE_DIR, help="Directory for downloaded images")
    parser.add_argument("--delay", type=float, default=DEFAULT_DELAY, help="Delay between page fetches in seconds")
    parser.add_argument("--proxy-service", default=os.getenv("SHREEJEE_PROXY_SERVICE", ""), help="Optional proxy service name: scraperapi or scrapingbee")
    parser.add_argument("--proxy-key", default=os.getenv("SHREEJEE_PROXY_KEY", ""), help="API key for the selected proxy service")
    parser.add_argument("--render-js", action="store_true", help="Ask the proxy service to render JavaScript when supported")
    parser.add_argument("--retries", type=int, default=DEFAULT_RETRY_COUNT, help="Retry count for blocked or flaky requests")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT, help="Request timeout in seconds")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    os.makedirs(args.image_dir, exist_ok=True)
    fetch_options = FetchOptions(
        proxy_service=args.proxy_service,
        api_key=args.proxy_key,
        render_js=bool(args.render_js),
        retries=max(1, int(args.retries)),
        timeout=max(1, int(args.timeout)),
    )
    final_woo_import_sheet = execute_shree_jee_scraper_pipeline(
        args.input,
        image_dir=args.image_dir,
        delay=args.delay,
        fetch_options=fetch_options,
    )
    final_woo_import_sheet.to_csv(args.output, index=False)
    print(f"\n[Success] Core processing engine run complete. Saved file: '{args.output}'")


if __name__ == "__main__":
    main()