import json
import re
from typing import Any
from urllib.parse import unquote, urlsplit

import requests
from bs4 import BeautifulSoup


HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )
}


def fetch_html(url: str) -> str:
    response = requests.get(url, headers=HEADERS, timeout=30)
    if response.status_code == 403:
        return fetch_html_with_selenium(url)

    response.raise_for_status()
    return response.text


def fetch_html_with_selenium(url: str) -> str:
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.webdriver import WebDriver as ChromeWebDriver
    from webdriver_manager.chrome import ChromeDriverManager

    options = Options()
    options.add_argument("--headless=new")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument(
        "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    )

    driver_factory: Any = ChromeWebDriver
    driver = driver_factory(
        service=Service(ChromeDriverManager().install()),
        options=options,
    )

    try:
        driver.get(url)
        return driver.page_source
    finally:
        driver.quit()


def to_high_quality_image_url(url: str) -> str:
    if "media-ik.croma.com/prod/" not in url:
        return url

    split_result = urlsplit(url)
    path = split_result.path
    marker = "/prod/"
    index = path.find(marker)
    if index == -1:
        return url

    encoded_original = path[index + len(marker) :]
    original = unquote(encoded_original)
    if original.startswith("https://") or original.startswith("http://"):
        return original
    return url


def extract_image_urls(soup: BeautifulSoup) -> list[str]:
    urls: list[str] = []

    def to_str_candidates(value: Any, srcset: bool = False) -> list[str]:
        if isinstance(value, list):
            raw_items = [str(v) for v in value]
        else:
            raw_items = [str(value)]

        if not srcset:
            return [item for item in raw_items if item]

        out: list[str] = []
        for item in raw_items:
            out.extend(
                part.strip().split(" ")[0]
                for part in item.split(",")
                if part.strip()
            )
        return out

    for img in soup.find_all("img"):
        for attr in ("src", "data-src", "data-lazy", "srcset"):
            value = img.get(attr)
            if not value:
                continue

            if attr == "srcset":
                candidates = to_str_candidates(value, srcset=True)
            else:
                candidates = to_str_candidates(value)

            for candidate in candidates:
                if (
                    (candidate.startswith("http") and "tatacroma" in candidate)
                    or "media-ik.croma.com" in candidate
                ):
                    urls.append(to_high_quality_image_url(candidate))

    # Deduplicate while preserving order.
    seen = set()
    unique_urls = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            unique_urls.append(u)

    return unique_urls


def extract_video_urls(html: str, soup: BeautifulSoup) -> list[str]:
    urls: list[str] = []

    def first_attr_str(value: Any) -> str:
        if isinstance(value, list):
            return str(value[0]) if value else ""
        return str(value) if value else ""

    for video in soup.find_all("video"):
        src = first_attr_str(video.get("src"))
        if src and src.startswith("http"):
            urls.append(src)
        for source in video.find_all("source"):
            src = first_attr_str(source.get("src"))
            if src and src.startswith("http"):
                urls.append(src)

    regexes = [
        r"https?://[^\"'\s]+\\.(?:mp4|webm|m3u8)",
        r"https?://(?:www\.)?youtube\.com/watch\?v=[\w-]+",
        r"https?://youtu\.be/[\w-]+",
        r"https?://player\.vimeo\.com/video/\d+",
    ]

    for pattern in regexes:
        urls.extend(re.findall(pattern, html, flags=re.IGNORECASE))

    seen = set()
    unique_urls = []
    for u in urls:
        if u not in seen:
            seen.add(u)
            unique_urls.append(u)

    return unique_urls


def extract_specifications(soup: BeautifulSoup) -> dict[str, str]:
    specs: dict[str, str] = {}

    for heading in soup.find_all(["h3", "h4"]):
        label = heading.get_text(" ", strip=True)
        if not label:
            continue

        sibling = heading.find_next_sibling()
        if not sibling:
            continue

        value = sibling.get_text(" ", strip=True)
        if value and len(label) < 120 and len(value) < 1000:
            if label.lower() in {"specifications", "overview", "key features"}:
                continue
            specs[label] = value

    # Fallback parsing for "#### Key / value" patterns in rendered text.
    text = soup.get_text("\n", strip=True)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    for i in range(len(lines) - 1):
        key = lines[i]
        value = lines[i + 1]
        if (
            2 <= len(key) <= 120
            and 1 <= len(value) <= 500
            and key not in specs
            and key.isupper() is False
            and not value.startswith("http")
        ):
            if key.lower() in {"specifications", "overview", "key features"}:
                continue
            specs[key] = value

    return specs


def extract_product_title(soup: BeautifulSoup) -> str:
    title = soup.find("h1")
    if title:
        return title.get_text(" ", strip=True)

    if soup.title:
        return soup.title.get_text(" ", strip=True)

    return ""


def extract_croma_assets(url: str) -> dict[str, Any]:
    html = fetch_html(url)
    soup = BeautifulSoup(html, "html.parser")

    return {
        "url": url,
        "title": extract_product_title(soup),
        "image_urls": extract_image_urls(soup),
        "video_urls": extract_video_urls(html, soup),
        "specifications": extract_specifications(soup),
    }


if __name__ == "__main__":
    PRODUCT_URL = (
        "https://www.croma.com/haier-80-cm-32-inch-full-hd-plus-qled-smart-google-tv-with-google-assistant-2025-model-/p/315156"
    )

    data = extract_croma_assets(PRODUCT_URL)
    print(json.dumps(data, indent=2, ensure_ascii=False))