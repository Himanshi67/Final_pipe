import pandas as pd
import re
import csv

from surgical_scraper import build_contextual_woo_tables, clean_spacing_matrix


def sanitize_html_layout(text):
    """Collapses all dangerous hidden line breaks and escapes quote boundaries."""
    if not text or pd.isna(text):
        return ""
    return clean_spacing_matrix(text)


def run_pipeline_sanitizer():
    input_sheet = "wordpress_ready.csv"
    output_sheet = "wordpress_ready_clean.csv"

    print(f"🚀 Initializing Cleaning Script Layer against: {input_sheet}")
    try:
        df = pd.read_csv(input_sheet, dtype=str)
    except FileNotFoundError:
        print(f"ERROR: {input_sheet} not found in current directory.")
        return

    scrubbed_rows = []

    for index, row in df.iterrows():
        sku = str(row.get('sku', '')).strip()
        title = str(row.get('title', '')).strip()
        category = str(row.get('categories', row.get('category', ''))).strip()
        brand = str(row.get('Brands', row.get('Brand', ''))).strip()

        print(f"   Cleaning row [{index + 1}] -> SKU: {sku}")

        # Build clean tables using the same contextual engine as the scraper.
        sanitized_bullets, sanitized_short, sanitized_long = build_contextual_woo_tables(title, sku, category, brand)

        updated_row = row.to_dict()
        updated_row['configuration'] = sanitize_html_layout(sanitized_bullets)
        updated_row['short description'] = sanitize_html_layout(sanitized_short)
        updated_row['description'] = sanitize_html_layout(sanitized_long)

        scrubbed_rows.append(updated_row)

    # Export with quoting to prevent cell spilling
    out_df = pd.DataFrame(scrubbed_rows)
    out_df.to_csv(output_sheet, index=False, quoting=csv.QUOTE_ALL)
    print(f"🎉 SUCCESS! Clean data matrix saved to: {output_sheet}")


if __name__ == "__main__":
    run_pipeline_sanitizer()
