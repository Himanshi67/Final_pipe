import requests
from surgical_scraper import download_product_image_bytes

urls = [
    "https://images.samsung.com/is/image/samsung/p6pim/in/wa80f10b3ntl/energylabel/in-energylabel-product-wa80f10b3ntl-552916356?$Q90_2052_1641_JPG$",
    "https://images.samsung.com/is/image/samsung/p6pim/in/wa80f10b3ntl/energylabel/in-energylabel-wa80f10b3ntl-552916354?$Q90_1368_1094_F_JPG$",
    "https://images.samsung.com/is/image/samsung/p6pim/in/wa80f10b3ntl/gallery/in-wa80f21-544055-wa80f10b3ntl-545824302?$Q90_1368_1094_F_JPG$",
]

s = requests.Session()
for u in urls:
    b = download_product_image_bytes(u, s)
    print(u, '->', 'OK' if b else 'FAILED', len(b) if b else 0)
